import 'package:agenda_cultural/data/eventos_data.dart';
import 'package:agenda_cultural/screens/detalhe_evento_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('encontra o evento pelo id recebido na notificação', () {
    expect(buscarEventoPorId('3')?.titulo, 'Concerto Sinfônico Amazônico');
    expect(buscarEventoPorId(' 3 ')?.id, '3');
    expect(buscarEventoPorId('99'), isNull);
    expect(buscarEventoPorId(null), isNull);
  });

  testWidgets('tela de detalhes mostra o aviso de notificação', (tester) async {
    await tester.pumpWidget(
      const MaterialApp(
        home: DetalheEventoScreen(eventoId: '3', abertoPorNotificacao: true),
      ),
    );
    expect(find.text('Concerto Sinfônico Amazônico'), findsOneWidget);
    expect(find.textContaining('Aberto a partir de uma notificação'),
        findsOneWidget);
  });
}
