// Service worker do Firebase Cloud Messaging — versão WEB do app.
// Recebe as notificações quando a aba do app está em segundo plano ou fechada.
//
// ATENÇÃO: cole aqui os MESMOS valores de lib/firebase_config_web.dart.
const firebaseConfig = {
  apiKey: 'COLE_AQUI_apiKey',
  authDomain: 'SEU-PROJETO.firebaseapp.com',
  projectId: 'SEU-PROJETO',
  storageBucket: 'SEU-PROJETO.firebasestorage.app',
  messagingSenderId: 'COLE_AQUI_messagingSenderId',
  appId: 'COLE_AQUI_appId',
};

// ---------------------------------------------------------------------------
// DESAFIO 3 na web: clique na notificação.
// Este listener precisa vir ANTES do importScripts do Firebase para rodar
// primeiro. Ele lê o dado personalizado "evento_id" enviado pelo console e:
//   - aba do app aberta (segundo plano) -> foca a aba e manda o evento_id
//   - app fechado                       -> abre o app com ?evento_id=3 na URL
// ---------------------------------------------------------------------------
self.addEventListener('notificationclick', (event) => {
  const fcm = event.notification && event.notification.data &&
      event.notification.data.FCM_MSG;
  if (!fcm) return; // não é notificação do FCM
  event.stopImmediatePropagation();
  event.notification.close();

  const dados = fcm.data || {};
  const eventoId = dados.evento_id ? String(dados.evento_id) : '';
  const titulo = (fcm.notification && fcm.notification.title) || '';

  const base = new URL('./', self.location.href); // pasta onde o app está
  const destino = new URL(base.href);
  if (eventoId) {
    destino.searchParams.set('evento_id', eventoId);
    destino.searchParams.set('titulo', titulo);
  }

  event.waitUntil((async () => {
    const janelas = await self.clients.matchAll({
      type: 'window',
      includeUncontrolled: true,
    });
    const janelaDoApp = janelas.find((c) => c.url.startsWith(base.href));
    if (janelaDoApp) {
      await janelaDoApp.focus();
      if (eventoId) {
        janelaDoApp.postMessage({
          tipo: 'abrir_evento',
          evento_id: eventoId,
          titulo: titulo,
        });
      }
      return;
    }
    await self.clients.openWindow(destino.href);
  })());
});

importScripts('https://www.gstatic.com/firebasejs/13.1.0/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/13.1.0/firebase-messaging-compat.js');

firebase.initializeApp(firebaseConfig);

// Necessário para receber mensagens em segundo plano. Notificações enviadas
// pelo Firebase Console (com título, texto e imagem) são exibidas
// automaticamente pelo SDK; aqui só registramos no console do navegador.
const messaging = firebase.messaging();
messaging.onBackgroundMessage((payload) => {
  console.log('[SW] Mensagem em segundo plano:', payload);
});
