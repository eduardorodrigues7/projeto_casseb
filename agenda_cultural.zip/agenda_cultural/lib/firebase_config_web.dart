import 'package:firebase_core/firebase_core.dart';

/// Configuração do Firebase para a versão WEB (navegador).
///
/// No Android o app usa o arquivo android/app/google-services.json e não
/// precisa deste arquivo.
///
/// ONDE PEGAR OS VALORES (Firebase Console):
///  1. Engrenagem > Configurações do projeto > Geral > "Seus apps" >
///     ícone </> (Web) > registre o app "Agenda Cultural Web".
///  2. Copie os valores do objeto `firebaseConfig` mostrado na tela.
///  3. VAPID: Configurações do projeto > Cloud Messaging >
///     "Certificados push da Web" > Gerar par de chaves > copie a chave.
///
/// ATENÇÃO: cole os MESMOS valores em web/firebase-messaging-sw.js.
class FirebaseConfigWeb {
  static const FirebaseOptions options = FirebaseOptions(
    apiKey: 'COLE_AQUI_apiKey',
    authDomain: 'SEU-PROJETO.firebaseapp.com',
    projectId: 'SEU-PROJETO',
    storageBucket: 'SEU-PROJETO.firebasestorage.app',
    messagingSenderId: 'COLE_AQUI_messagingSenderId',
    appId: 'COLE_AQUI_appId',
  );

  /// Chave pública "Web Push certificate" (par de chaves VAPID).
  static const String vapidKey = 'COLE_AQUI_A_CHAVE_VAPID';
}
