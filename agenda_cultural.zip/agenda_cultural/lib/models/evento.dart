/// Representa um evento da agenda cultural.
///
/// O [id] é uma String porque é exatamente esse valor que chega no campo
/// `data` da mensagem do Firebase Cloud Messaging (FCM), onde todos os
/// valores são texto. Ex.: { "evento_id": "3" }.
class Evento {
  const Evento({
    required this.id,
    required this.titulo,
    required this.categoria,
    required this.data,
    required this.horario,
    required this.local,
    required this.preco,
    required this.descricao,
    required this.imagem,
    this.destaque = false,
  });

  final String id;
  final String titulo;
  final String categoria;
  final String data;
  final String horario;
  final String local;
  final String preco;
  final String descricao;

  /// Caminho do asset local (ex.: assets/eventos/carimbo.jpg).
  final String imagem;

  /// Evento em destaque da semana (aparece no topo da tela inicial).
  final bool destaque;
}
