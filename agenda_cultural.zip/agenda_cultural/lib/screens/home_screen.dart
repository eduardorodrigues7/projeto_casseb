import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../data/eventos_data.dart';
import '../models/evento.dart';
import '../services/notification_service.dart';
import '../widgets/evento_card.dart';
import 'detalhe_evento_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  void _abrir(BuildContext context, Evento evento) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => DetalheEventoScreen(eventoId: evento.id),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final destaque = eventoEmDestaque;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Agenda Cultural Belém'),
        actions: [
          IconButton(
            tooltip: 'Painel de notificações',
            icon: const Icon(Icons.notifications_outlined),
            onPressed: () => _mostrarPainel(context),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.only(bottom: 24),
        children: [
          const _BannerPermissao(),
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
            child: Text(
              'Destaque da semana',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ),
          _CardDestaque(evento: destaque, onTap: () => _abrir(context, destaque)),
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 20, 16, 8),
            child: Text(
              'Próximos eventos',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ),
          for (final evento in eventos.where((e) => !e.destaque))
            EventoCard(evento: evento, onTap: () => _abrir(context, evento)),
        ],
      ),
    );
  }

  void _mostrarPainel(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => const _PainelNotificacoes(),
    );
  }
}

/// Aparece enquanto as notificações não estiverem permitidas.
/// Na web o navegador só mostra o pedido de permissão após um clique.
class _BannerPermissao extends StatelessWidget {
  const _BannerPermissao();

  @override
  Widget build(BuildContext context) {
    final servico = NotificationService.instance;
    return ValueListenableBuilder<bool>(
      valueListenable: servico.permissaoConcedida,
      builder: (context, permitido, _) {
        if (permitido) return const SizedBox.shrink();
        final cores = Theme.of(context).colorScheme;
        return Card(
          color: cores.primaryContainer,
          margin: const EdgeInsets.fromLTRB(16, 16, 16, 0),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Receba avisos da programação',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: cores.onPrimaryContainer,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Ative as notificações para saber quando sair a agenda, '
                  'quem é o destaque da semana e quando os ingressos estão '
                  'acabando.',
                  style: TextStyle(color: cores.onPrimaryContainer),
                ),
                const SizedBox(height: 12),
                FilledButton.icon(
                  icon: const Icon(Icons.notifications_active),
                  label: const Text('Ativar notificações'),
                  onPressed: servico.ativarNotificacoes,
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _CardDestaque extends StatelessWidget {
  const _CardDestaque({required this.evento, required this.onTap});

  final Evento evento;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      margin: const EdgeInsets.symmetric(horizontal: 16),
      child: InkWell(
        onTap: onTap,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            AspectRatio(
              aspectRatio: 2,
              child: Image.asset(evento.imagem, fit: BoxFit.cover),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    evento.titulo,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text('${evento.data} · ${evento.horario} · ${evento.preco}'),
                  Text(evento.local),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Painel usado nos testes e no vídeo: mostra a permissão, o token FCM do
/// aparelho (para "Enviar mensagem de teste" no Firebase Console) e o
/// histórico de notificações tratadas pelo app.
class _PainelNotificacoes extends StatelessWidget {
  const _PainelNotificacoes();

  @override
  Widget build(BuildContext context) {
    final servico = NotificationService.instance;
    return DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.6,
      maxChildSize: 0.95,
      builder: (context, scrollController) => ListView(
        controller: scrollController,
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
        children: [
          const Text(
            'Painel de notificações',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          ValueListenableBuilder<String>(
            valueListenable: servico.statusPermissao,
            builder: (_, status, _) => ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.verified_user_outlined),
              title: const Text('Permissão de notificações'),
              subtitle: Text(status),
            ),
          ),
          const Text(
            'Token FCM deste aparelho',
            style: TextStyle(fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 6),
          ValueListenableBuilder<String?>(
            valueListenable: servico.token,
            builder: (context, token, _) => Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ValueListenableBuilder<String?>(
                  valueListenable: servico.erroToken,
                  builder: (_, erro, _) => erro == null
                      ? const SizedBox.shrink()
                      : Text(
                          'Erro ao obter token: $erro',
                          style: const TextStyle(color: Colors.red),
                        ),
                ),
                SelectableText(
                  token ?? 'ative as notificações para gerar o token',
                  style: const TextStyle(fontFamily: 'monospace', fontSize: 12),
                ),
                TextButton.icon(
                  icon: const Icon(Icons.copy),
                  label: const Text('Copiar token'),
                  onPressed: token == null
                      ? null
                      : () {
                          Clipboard.setData(ClipboardData(text: token));
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Token copiado')),
                          );
                        },
                ),
              ],
            ),
          ),
          const Divider(height: 24),
          const Text(
            'Notificações tratadas pelo app',
            style: TextStyle(fontWeight: FontWeight.w600),
          ),
          ValueListenableBuilder<List<NotificacaoRecebida>>(
            valueListenable: servico.historico,
            builder: (_, lista, _) {
              if (lista.isEmpty) {
                return const Padding(
                  padding: EdgeInsets.symmetric(vertical: 12),
                  child: Text(
                    'Nenhuma ainda. Notificações que chegam com o app em '
                    'segundo plano só aparecem aqui depois de tocadas.',
                  ),
                );
              }
              return Column(
                children: [
                  for (final n in lista)
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: Icon(
                        n.imagemUrl != null
                            ? Icons.image_outlined
                            : Icons.notifications_none,
                      ),
                      title: Text(n.titulo),
                      subtitle: Text(
                        '${_hora(n.horario)} · ${n.origem}'
                        '${n.eventoId != null ? ' · evento_id=${n.eventoId}' : ''}',
                      ),
                    ),
                ],
              );
            },
          ),
        ],
      ),
    );
  }

  String _hora(DateTime d) =>
      '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
}
