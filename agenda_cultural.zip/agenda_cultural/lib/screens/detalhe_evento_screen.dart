import 'package:flutter/material.dart';

import '../data/eventos_data.dart';
import '../models/evento.dart';

/// Tela de detalhes. Recebe apenas o id do evento — o mesmo valor que chega
/// no campo `evento_id` da notificação (Desafio 3).
class DetalheEventoScreen extends StatelessWidget {
  const DetalheEventoScreen({
    super.key,
    required this.eventoId,
    this.abertoPorNotificacao = false,
  });

  final String eventoId;
  final bool abertoPorNotificacao;

  @override
  Widget build(BuildContext context) {
    final evento = buscarEventoPorId(eventoId);
    if (evento == null) {
      return _EventoNaoEncontrado(eventoId: eventoId);
    }
    return _ConteudoEvento(
      evento: evento,
      abertoPorNotificacao: abertoPorNotificacao,
    );
  }
}

class _ConteudoEvento extends StatelessWidget {
  const _ConteudoEvento({
    required this.evento,
    required this.abertoPorNotificacao,
  });

  final Evento evento;
  final bool abertoPorNotificacao;

  @override
  Widget build(BuildContext context) {
    final cores = Theme.of(context).colorScheme;
    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 220,
            pinned: true,
            flexibleSpace: FlexibleSpaceBar(
              background: Image.asset(evento.imagem, fit: BoxFit.cover),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (abertoPorNotificacao)
                    Container(
                      width: double.infinity,
                      margin: const EdgeInsets.only(bottom: 16),
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: cores.tertiaryContainer,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            Icons.notifications_active,
                            color: cores.onTertiaryContainer,
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              'Aberto a partir de uma notificação '
                              '(evento_id = ${evento.id})',
                              style: TextStyle(
                                color: cores.onTertiaryContainer,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  Chip(label: Text(evento.categoria)),
                  const SizedBox(height: 8),
                  Text(
                    evento.titulo,
                    style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 16),
                  _Info(icone: Icons.event, texto: evento.data),
                  _Info(icone: Icons.schedule, texto: evento.horario),
                  _Info(icone: Icons.place, texto: evento.local),
                  _Info(icone: Icons.confirmation_number, texto: evento.preco),
                  const Divider(height: 32),
                  Text(
                    'Sobre o evento',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    evento.descricao,
                    style: const TextStyle(fontSize: 16, height: 1.5),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Info extends StatelessWidget {
  const _Info({required this.icone, required this.texto});

  final IconData icone;
  final String texto;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Icon(icone, size: 20, color: Theme.of(context).colorScheme.primary),
          const SizedBox(width: 10),
          Expanded(child: Text(texto, style: const TextStyle(fontSize: 15))),
        ],
      ),
    );
  }
}

class _EventoNaoEncontrado extends StatelessWidget {
  const _EventoNaoEncontrado({required this.eventoId});

  final String eventoId;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Evento não encontrado')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text(
            'A notificação pediu o evento "$eventoId", mas ele não existe '
            'na agenda. Confira o valor de evento_id (use de 1 a 5).',
            textAlign: TextAlign.center,
          ),
        ),
      ),
    );
  }
}
