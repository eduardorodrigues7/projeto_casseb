import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';

import 'firebase_config_web.dart';
import 'screens/home_screen.dart';
import 'services/notification_service.dart';

/// Handler de mensagens recebidas com o app em SEGUNDO PLANO ou FECHADO.
///
/// Mensagens do tipo "notificação" (as enviadas pelo Firebase Console) são
/// exibidas automaticamente pelo próprio Android — inclusive com imagem.
/// Este handler serve apenas para registrar no log (Logcat) que a mensagem
/// chegou. Precisa ser uma função de nível superior e ter @pragma.
@pragma('vm:entry-point')
Future<void> firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp();
  debugPrint(
    '[FCM] Mensagem recebida em segundo plano: '
    '${message.notification?.title} | data=${message.data}',
  );
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Android: usa o android/app/google-services.json.
  // Web: usa as chaves coladas em lib/firebase_config_web.dart.
  await Firebase.initializeApp(
    options: kIsWeb ? FirebaseConfigWeb.options : null,
  );

  // Na web, o segundo plano é tratado pelo web/firebase-messaging-sw.js.
  if (!kIsWeb) {
    FirebaseMessaging.onBackgroundMessage(firebaseMessagingBackgroundHandler);
  }

  runApp(const AgendaCulturalApp());

  // Permissão, token e listeners (não bloqueia a abertura do app).
  NotificationService.instance.inicializar();
}

class AgendaCulturalApp extends StatefulWidget {
  const AgendaCulturalApp({super.key});

  @override
  State<AgendaCulturalApp> createState() => _AgendaCulturalAppState();
}

class _AgendaCulturalAppState extends State<AgendaCulturalApp> {
  @override
  void initState() {
    super.initState();
    // Depois do primeiro frame o Navigator já existe: aí verificamos se o
    // app foi ABERTO pelo toque numa notificação (app estava fechado).
    WidgetsBinding.instance.addPostFrameCallback((_) {
      NotificationService.instance.verificarMensagemInicial();
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Agenda Cultural Belém',
      debugShowCheckedModeBanner: false,
      navigatorKey: navigatorKey,
      scaffoldMessengerKey: messengerKey,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF0F766E), // verde-azulado amazônico
        ),
      ),
      home: const HomeScreen(),
    );
  }
}
