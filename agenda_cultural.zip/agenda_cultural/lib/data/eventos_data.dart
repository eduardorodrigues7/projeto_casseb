import '../models/evento.dart';

/// Dados do aplicativo definidos no próprio código
/// (a atividade dispensa banco de dados e backend).
/// Eventos fictícios, criados apenas para esta atividade.
const List<Evento> eventos = [
  Evento(
    id: '1',
    titulo: 'Festival de Carimbó na Praça',
    categoria: 'Música e dança',
    data: 'Sáb, 21 de novembro',
    horario: '18h',
    local: 'Praça da República, Belém',
    preco: 'Gratuito',
    descricao:
        'Uma noite inteira de carimbó com grupos de Marapanim, Santarém Novo '
        'e Belém. Roda aberta para o público, oficina de dança às 18h e '
        'feirinha de artesanato. Leve sua saia rodada!',
    imagem: 'assets/eventos/carimbo.jpg',
    destaque: true,
  ),
  Evento(
    id: '2',
    titulo: 'Feira de Sabores do Pará',
    categoria: 'Gastronomia',
    data: 'Dom, 22 de novembro',
    horario: '10h às 16h',
    local: 'Estação das Docas, Belém',
    preco: 'Entrada gratuita',
    descricao:
        'Tacacá, maniçoba, açaí com peixe frito e doces de cupuaçu preparados '
        'por cozinheiras e cozinheiros paraenses. Aula-show de pato no '
        'tucupi às 11h.',
    imagem: 'assets/eventos/gastronomia.jpg',
  ),
  Evento(
    id: '3',
    titulo: 'Concerto Sinfônico Amazônico',
    categoria: 'Música erudita',
    data: 'Sex, 27 de novembro',
    horario: '20h',
    local: 'Theatro da Paz, Belém',
    preco: 'R\$ 20 (meia R\$ 10)',
    descricao:
        'Orquestra apresenta releituras sinfônicas de compositores paraenses, '
        'de Waldemar Henrique ao brega. Restam poucos ingressos — '
        'chegue com 30 minutos de antecedência.',
    imagem: 'assets/eventos/concerto.jpg',
  ),
  Evento(
    id: '4',
    titulo: 'Mostra de Cinema Amazônida',
    categoria: 'Cinema',
    data: 'Sáb, 28 de novembro',
    horario: '15h',
    local: 'Cine Olympia, Belém',
    preco: 'Gratuito (senhas 1h antes)',
    descricao:
        'Sessão de curtas-metragens produzidos na região Norte, seguida de '
        'bate-papo com diretoras e diretores.',
    imagem: 'assets/eventos/cinema.jpg',
  ),
  Evento(
    id: '5',
    titulo: 'Exposição Arte Marajoara',
    categoria: 'Artes visuais',
    data: '1 a 15 de dezembro',
    horario: '9h às 17h',
    local: 'Espaço cultural, Cidade Velha',
    preco: 'R\$ 10',
    descricao:
        'Cerâmicas, grafismos e peças contemporâneas inspiradas na arte '
        'marajoara. Visitas guiadas às 10h e às 15h.',
    imagem: 'assets/eventos/marajoara.jpg',
  ),
];

/// Procura um evento pelo id recebido na notificação.
/// Retorna null quando o id não existe (ou veio vazio).
Evento? buscarEventoPorId(String? id) {
  if (id == null) return null;
  final idLimpo = id.trim();
  for (final evento in eventos) {
    if (evento.id == idLimpo) return evento;
  }
  return null;
}

Evento get eventoEmDestaque =>
    eventos.firstWhere((e) => e.destaque, orElse: () => eventos.first);
