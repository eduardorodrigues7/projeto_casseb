// Versão usada no Android: não existe service worker nem URL,
// então as funções não fazem nada.

void ouvirCliquesDoServiceWorker(
  void Function(String eventoId, String? titulo) aoClicar,
) {}

void limparParametrosDaUrl() {}
