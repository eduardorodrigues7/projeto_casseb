import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';

import '../firebase_config_web.dart';
import '../screens/detalhe_evento_screen.dart';
import 'ponte_web_stub.dart' if (dart.library.js_interop) 'ponte_web.dart';

/// Chaves globais: permitem navegar e mostrar avisos a partir do serviço,
/// fora da árvore de widgets (ex.: quando a notificação é tocada).
final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();
final GlobalKey<ScaffoldMessengerState> messengerKey =
    GlobalKey<ScaffoldMessengerState>();

/// Chave do campo `data` usada no Desafio 3 para identificar o conteúdo.
/// No Firebase Console: Opções adicionais > Dados personalizados
///   chave: evento_id   valor: 3
const String chaveEventoId = 'evento_id';

/// Registro de uma notificação, exibido no painel de testes do app.
class NotificacaoRecebida {
  NotificacaoRecebida({
    required this.titulo,
    required this.corpo,
    required this.origem,
    required this.eventoId,
    required this.imagemUrl,
  }) : horario = DateTime.now();

  final String titulo;
  final String corpo;

  /// 'primeiro plano', 'segundo plano (toque)' ou 'app fechado (toque)'.
  final String origem;
  final String? eventoId;
  final String? imagemUrl;
  final DateTime horario;
}

class NotificationService {
  NotificationService._();
  static final NotificationService instance = NotificationService._();

  final FirebaseMessaging _messaging = FirebaseMessaging.instance;

  final ValueNotifier<String?> token = ValueNotifier<String?>(null);
  final ValueNotifier<String?> erroToken = ValueNotifier<String?>(null);
  final ValueNotifier<bool> permissaoConcedida = ValueNotifier<bool>(false);
  final ValueNotifier<String> statusPermissao =
      ValueNotifier<String>('verificando...');
  final ValueNotifier<List<NotificacaoRecebida>> historico =
      ValueNotifier<List<NotificacaoRecebida>>(<NotificacaoRecebida>[]);

  bool _mensagemInicialTratada = false;

  /// Android: pede a permissão logo ao abrir (Android 13+ exige
  /// POST_NOTIFICATIONS em tempo de execução) e obtém o token.
  /// Web: o navegador só mostra o pedido de permissão depois de um clique,
  /// então aqui apenas verificamos; o botão "Ativar notificações" da tela
  /// inicial chama [ativarNotificacoes].
  Future<void> inicializar() async {
    // Listeners primeiro, para não perder nenhuma mensagem.

    // App ABERTO (primeiro plano): nem o Android nem o navegador mostram a
    // notificação sozinhos. Mostramos um aviso dentro do app.
    FirebaseMessaging.onMessage.listen(_aoReceberEmPrimeiroPlano);

    // Android: app em SEGUNDO PLANO e o usuário TOCA na notificação.
    FirebaseMessaging.onMessageOpenedApp.listen(
      (message) => _aoTocarNaNotificacao(message, 'segundo plano (toque)'),
    );

    // Web: clique na notificação com a aba do app já aberta (segundo plano),
    // repassado pelo web/firebase-messaging-sw.js.
    ouvirCliquesDoServiceWorker(
      (eventoId, titulo) => _aoTocarNaWeb(
        eventoId: eventoId,
        titulo: titulo,
        origem: 'segundo plano (toque)',
      ),
    );

    if (kIsWeb) {
      final settings = await _messaging.getNotificationSettings();
      _atualizarPermissao(settings.authorizationStatus);
      if (settings.authorizationStatus == AuthorizationStatus.authorized) {
        await _obterToken();
      }
    } else {
      // ignore: deprecated_member_use
      _messaging.onTokenRefresh.listen((novo) => token.value = novo);
      await ativarNotificacoes();
    }
  }

  /// Pede a permissão e, se concedida, obtém o token do aparelho/navegador.
  Future<void> ativarNotificacoes() async {
    final settings = await _messaging.requestPermission(
      alert: true,
      badge: true,
      sound: true,
    );
    _atualizarPermissao(settings.authorizationStatus);
    if (settings.authorizationStatus == AuthorizationStatus.authorized ||
        settings.authorizationStatus == AuthorizationStatus.provisional) {
      await _obterToken();
    }
  }

  Future<void> _obterToken() async {
    try {
      // getToken continua sendo o token aceito em
      // "Enviar mensagem de teste" do Firebase Console.
      // ignore: deprecated_member_use
      token.value = await _messaging.getToken(
        vapidKey: kIsWeb ? FirebaseConfigWeb.vapidKey : null,
      );
      debugPrint('==================== FCM TOKEN ====================');
      debugPrint(token.value);
      debugPrint('===================================================');
    } catch (e) {
      token.value = null;
      erroToken.value = e.toString();
      debugPrint('[FCM] Erro ao obter token: $e');
    }
  }

  void _atualizarPermissao(AuthorizationStatus status) {
    permissaoConcedida.value = status == AuthorizationStatus.authorized ||
        status == AuthorizationStatus.provisional;
    statusPermissao.value = _descreverPermissao(status);
  }

  /// App FECHADO e aberto pelo toque na notificação.
  /// Android: getInitialMessage().
  /// Web: o service worker abre a página com ?evento_id=3 na URL.
  /// Deve ser chamado depois que o Navigator já existe (após o 1º frame).
  Future<void> verificarMensagemInicial() async {
    if (_mensagemInicialTratada) return;
    _mensagemInicialTratada = true;

    if (kIsWeb) {
      final params = Uri.base.queryParameters;
      final eventoId = params[chaveEventoId];
      if (eventoId != null && eventoId.isNotEmpty) {
        _aoTocarNaWeb(
          eventoId: eventoId,
          titulo: params['titulo'],
          origem: 'app fechado (toque)',
        );
        limparParametrosDaUrl();
      }
      return;
    }

    final message = await _messaging.getInitialMessage();
    if (message != null) {
      _aoTocarNaNotificacao(message, 'app fechado (toque)');
    }
  }

  // ---------------------------------------------------------------------------
  // Tratamento das mensagens
  // ---------------------------------------------------------------------------

  void _aoTocarNaNotificacao(RemoteMessage message, String origem) {
    _registrar(message, origem);
    debugPrint('[FCM] Notificação tocada ($origem). data=${message.data}');

    // Desafio 3: interpreta os dados recebidos e encaminha ao conteúdo.
    final eventoId = message.data[chaveEventoId]?.toString();
    if (eventoId != null && eventoId.isNotEmpty) {
      abrirEvento(eventoId);
    }
    // Sem evento_id (Desafios 1 e 2): o app simplesmente abre na tela inicial.
  }

  /// Web: clique tratado pelo service worker (segundo plano ou app fechado).
  void _aoTocarNaWeb({
    required String eventoId,
    required String? titulo,
    required String origem,
  }) {
    _adicionarAoHistorico(
      NotificacaoRecebida(
        titulo: (titulo == null || titulo.isEmpty) ? '(notificação)' : titulo,
        corpo: '',
        origem: origem,
        eventoId: eventoId,
        imagemUrl: null,
      ),
    );
    debugPrint('[FCM] Notificação tocada na web ($origem). evento_id=$eventoId');
    abrirEvento(eventoId);
  }

  void _aoReceberEmPrimeiroPlano(RemoteMessage message) {
    _registrar(message, 'primeiro plano');
    debugPrint('[FCM] Mensagem em primeiro plano. data=${message.data}');

    final notification = message.notification;
    final eventoId = message.data[chaveEventoId]?.toString();
    final imagemUrl = _imagemDa(message);

    messengerKey.currentState
      ?..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          behavior: SnackBarBehavior.floating,
          duration: const Duration(seconds: 8),
          content: Row(
            children: [
              if (imagemUrl != null && imagemUrl.isNotEmpty) ...[
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: Image.network(
                    imagemUrl,
                    width: 64,
                    height: 64,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) =>
                        const SizedBox.shrink(),
                  ),
                ),
                const SizedBox(width: 12),
              ],
              Expanded(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      notification?.title ?? 'Nova notificação',
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    if (notification?.body != null) Text(notification!.body!),
                  ],
                ),
              ),
            ],
          ),
          action: (eventoId != null && eventoId.isNotEmpty)
              ? SnackBarAction(
                  label: 'VER',
                  onPressed: () => abrirEvento(eventoId),
                )
              : null,
        ),
      );
  }

  /// Abre a tela de detalhes do evento, sempre a partir da tela inicial,
  /// para que o botão "voltar" leve o usuário de volta à agenda.
  void abrirEvento(String eventoId) {
    final navigator = navigatorKey.currentState;
    if (navigator == null) {
      debugPrint('[FCM] Navigator ainda não está pronto.');
      return;
    }
    navigator.popUntil((route) => route.isFirst);
    navigator.push(
      MaterialPageRoute<void>(
        settings: RouteSettings(name: '/evento/$eventoId'),
        builder: (_) =>
            DetalheEventoScreen(eventoId: eventoId, abertoPorNotificacao: true),
      ),
    );
  }

  void _registrar(RemoteMessage message, String origem) {
    final registro = NotificacaoRecebida(
      titulo: message.notification?.title ?? '(sem título)',
      corpo: message.notification?.body ?? '',
      origem: origem,
      eventoId: message.data[chaveEventoId]?.toString(),
      imagemUrl: _imagemDa(message),
    );
    _adicionarAoHistorico(registro);
  }

  void _adicionarAoHistorico(NotificacaoRecebida registro) {
    historico.value = [registro, ...historico.value];
  }

  /// A URL da imagem vem em campos diferentes no Android e na web.
  String? _imagemDa(RemoteMessage message) =>
      message.notification?.android?.imageUrl ??
      message.notification?.web?.image;

  String _descreverPermissao(AuthorizationStatus status) {
    switch (status) {
      case AuthorizationStatus.authorized:
        return 'permitidas';
      case AuthorizationStatus.provisional:
        return 'provisórias';
      case AuthorizationStatus.denied:
        return 'negadas — libere nas configurações do navegador/Android';
      case AuthorizationStatus.notDetermined:
        return 'não definidas';
    }
  }
}
