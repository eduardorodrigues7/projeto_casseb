// Versão usada no NAVEGADOR (compilada só na web).
//
// O web/firebase-messaging-sw.js trata o clique na notificação. Quando a aba
// do app já está aberta (app em segundo plano), ele foca a aba e envia
// { tipo: 'abrir_evento', evento_id: '3' } — que recebemos aqui.
import 'dart:js_interop';

import 'package:web/web.dart' as web;

void ouvirCliquesDoServiceWorker(
  void Function(String eventoId, String? titulo) aoClicar,
) {
  final container = web.window.navigator.serviceWorker;
  container.addEventListener(
    'message',
    ((web.MessageEvent evento) {
      final dados = evento.data.dartify();
      if (dados is Map && dados['tipo'] == 'abrir_evento') {
        final id = dados['evento_id']?.toString();
        if (id != null && id.isNotEmpty) {
          aoClicar(id, dados['titulo']?.toString());
        }
      }
    }).toJS,
  );
  container.startMessages();
}

/// Remove ?evento_id=... da barra de endereço depois de usado, para que
/// recarregar a página não abra o evento de novo.
void limparParametrosDaUrl() {
  final local = web.window.location;
  if (local.search.isEmpty) return;
  web.window.history.replaceState(null, '', '${local.pathname}${local.hash}');
}
